function useModal(id) {
	let modal = document.getElementById(id);
	modal.classList.add('open');

	window.onclick = function(event) {
		if (event.target == modal) {
			modal.classList.remove('open');
		}
	}
}

function closeModalParent(button) {
	let parent = button;
	while (parent = parent.parentNode) {
		if (parent.classList.contains('modal')) {
			parent.classList.remove('open');
			break;
		}
	}
}

function useAccordeon(id) {
	let accordeon = document.getElementById(id);
	if (accordeon.classList.contains('open')) {
		accordeon.classList.remove('open');
	} else {
		accordeon.classList.add('open');
	}
}